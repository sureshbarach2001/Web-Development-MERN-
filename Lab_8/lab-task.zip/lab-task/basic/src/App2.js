import './nav.css';
import Nav from './components/nav.js';
import Application from './components/qu5.js';
function App(){

    return(

    <>
    <Nav />
    <Application />
    </>
    )
}
export default App