export default function Nav(){
    return(
        <>
        <div className="Nav">
            <div className="center">

            <div className="home">Home</div>
            <div className="product">Add Products</div>
            <div className="update">Update Products</div>
            <div className="profile">Profile</div>
            <div className="login">Login</div>
            </div>
        </div>
        </>
    )
}