export default function MyButton() {
    return (
      <button><a
      href="https://www.bing.com/ck/a?!&&p=1ec9ea588e42e6feJmltdHM9MTcxMDgwNjQwMCZpZ3VpZD0yYmIwODMyMS1lMDNkLTZjYjQtMDFlNS05NzMxZTFhNDZkNGUmaW5zaWQ9NTE5OA&ptn=3&ver=2&hsh=3&fclid=2bb08321-e03d-6cb4-01e5-9731e1a46d4e&psq=w3schools&u=a1aHR0cHM6Ly93d3cudzNzY2hvb2xzLmNvbS8&ntb=1"
      target="_blank"
      rel="noopener noreferrer"
    >
        W3 School
        </a>
      </button>
    );
  }