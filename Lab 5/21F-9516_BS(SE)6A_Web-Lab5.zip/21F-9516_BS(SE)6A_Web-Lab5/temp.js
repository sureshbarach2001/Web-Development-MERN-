const myMessage = "Hello from myModule!";

function displayMessage() {
  console.log(myMessage);
}

module.exports = {
  displayMessage,
  myMessage
};