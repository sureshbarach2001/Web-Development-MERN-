
let x = 10;
let y = 5;
const displayMessage = () => `-3-> X-Value {${x}} , Y-Value {${y}} ==>> Addition {${x+y}}`;

module.exports = {
  displayMessage,
};