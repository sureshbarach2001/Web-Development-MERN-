let x = 10;
let y = 5;
const displayMessage = () => `-1-> X-Value {${x}} , Y-Value {${y}} ==>> Substraction {${x-y}}`;

module.exports = {
  displayMessage,
};