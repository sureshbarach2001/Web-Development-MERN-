let x = 10;
let y = 5;
const displayMessage = () => `-2-> X-Value {${x}} , Y-Value {${y}} ==>> Multiplication {${x*y}}`;

module.exports = {
  displayMessage,
};