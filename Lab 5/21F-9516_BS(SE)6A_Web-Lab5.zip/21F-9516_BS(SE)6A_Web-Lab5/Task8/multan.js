let x = 10;
let y = 5;
const displayMessage = () => `-5-> X-Value {${x}} , Y-Value {${y}} ==>> Divide {${x/y}}`;

module.exports = {
  displayMessage,
};