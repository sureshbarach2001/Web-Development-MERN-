const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));

app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/Task1.html');
});
let users = [
    { id: 1, username: "aman", password: 1234 },
    { id: 2, username: "ahmad", password: 123 },
    { id: 3, username: "ali", password: 123456 },
    { id: 4, username: "hasan", password: 1234 },
    { id: 5, username: "akbar", password: 123 },
    { id: 6, username: "shera", password: 1234 }
]
app.post('/login', (req, res) => {
    const { username, password, confirm_password, email } = req.body;
    
    if (username === 'Suresh' && password === 'sain' && password === confirm_password) {
        res.redirect('/success?username=' + username);
    } else {
        res.redirect('/?invalid=true');
    }
});

app.get('/success', (req, res) => {
    const { username } = req.query;
    res.send(`Welcome, ${username}!`);
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});